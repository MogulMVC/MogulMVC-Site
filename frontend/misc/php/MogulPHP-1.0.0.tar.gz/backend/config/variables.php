<?php

// Example
// $GLOBALS['var'] = value;
