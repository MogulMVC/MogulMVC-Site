<?php

echo 'This is an example command.<br />For security reasons commands require a password, which you have obviously provided.';
