<?php

// Require all cron you want to run.
// require('myCronJob.php');
