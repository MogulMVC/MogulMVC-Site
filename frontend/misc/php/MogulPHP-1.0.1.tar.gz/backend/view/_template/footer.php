</div><!--MMainWindow-->

<footer id="MFooter">
	
	<!-- Your footer goes here -->
	
</footer>