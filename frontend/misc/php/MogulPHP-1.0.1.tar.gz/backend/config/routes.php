<?php

// Any subpage to controller with function
// $ROUTE['page/*'] = 'Controller/function';
//
// Any number to controller with function
// $ROUTE['page/#'] = 'Controller/function';
//
// Any string to controller with function
// $ROUTE['page/@'] = 'Controller/function';
//
// Page to controller with function
// $ROUTE['page/subpage'] = 'Controller/function';
