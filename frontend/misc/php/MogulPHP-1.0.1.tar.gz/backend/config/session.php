<?php

$GLOBALS['SESSION_DB'] = false;

$GLOBALS['SESSION'] = array(

	'type' => 'dbtype',
	'host' => 'localhost',
	'port' => '3306',
	'name' => 'dbname',
	'user' => 'dbuser',
	'pass' => 'dbpass',
	'table' => 'dbtable'
		
);