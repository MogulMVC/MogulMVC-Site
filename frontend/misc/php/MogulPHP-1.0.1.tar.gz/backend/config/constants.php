<?php

// Example
// define('COST', 'value');
